/**
 *
 * @author Reece Parry
 * @version 09/07/2025
 * 
 */
public class Client {
    
    public static void main(String[] args) {
        
        Employee[] employeeList = new Employee[10];
        
        employeeList[0] = new Salaried(1, "Al", "Manager", 60000);
        employeeList[1] = new Hourly(2, "Kelly", "Hostess", 25.75);
        employeeList[2] = new Salaried(3, "Peggy", "CEO", 120000);
        employeeList[3] = new Hourly(4, "Bud", "Busboy", 15.00);
        employeeList[4] = new Hourly(5, "Marcy", "Server", 10.00);
        employeeList[5] = new Hourly(6, "Jefferson", "Cook", 35.00);
        
        System.out.println("--- Employee List ---");
        for (Employee e : employeeList) {
            System.out.println(e);
        }
                                                                            
        // apply 33% raise
        for (Employee e : employeeList) {
            if (e instanceof Salaried) {
                Salaried s = (Salaried) e;
                s.setSalary((int)(s.getSalary() * 1.33));
            } else if (e instanceof Hourly) {
                Hourly h = (Hourly) e;
                h.setHourlyRate(h.getHourlyRate() * 1.33);
            }
        }
        
        // print without nulls
        System.out.println("\n--- Employee List (after raises) ---");
        for (Employee e : employeeList) {
            if (e != null) {
                System.out.println(e);
            }
        }
        
        // test equals
        System.out.println("\n--- Equals Tests ---");
        Salaried s1 = new Salaried(7, "Joe", "Manager", 60000);
        Salaried s2 = new Salaried(7, "Joe", "Manager", 60000);
        Salaried s3 = new Salaried(8, "Joe", "CEO", 80000);
        System.out.println("Salaried equals true? " + s1.equals(s2));
        System.out.println("Salaried equals false? " + s1.equals(s3));

        Hourly h1 = new Hourly(9, "Bob", "Cook", 20.0);
        Hourly h2 = new Hourly(9, "Bob", "Cook", 20.0);
        Hourly h3 = new Hourly(10, "Bob", "Host", 22.0);
        System.out.println("Hourly equals true? " + h1.equals(h2));
        System.out.println("Hourly equals false? " + h1.equals(h3));
        
        System.out.println("\nTotal Employees: " + Employee.getEmployeeCount());
        System.out.println("Total Salaried: " + Salaried.getSalariedCount());
        System.out.println("Total Hourly: " + Hourly.getHourlyCount());
    }
}
