/**
 *
 * @author Reece Parry
 * @version 09/07/2025
 */
public class Hourly extends Employee {
    
    private static int hourlyCount = 0;
    private String position;    // position name
    private double hourlyRate;     // hourly pay
    
    /**
     * 
     * @param id
     * @param name
     * @param position
     * @param hourlyRate
     */
    
    public Hourly(int id, String name, String position, double hourlyRate) {
        super(id, name);
        this.position = position;
        this.hourlyRate = hourlyRate;
        hourlyCount++;
    }
    
    public String getPosition( ) {return position;}
    
    public void setPosition(String position) {this.position = position;}
    
    public double getHourlyRate( ) {return hourlyRate; }
    
    public void setHourlyRate(double hourlyRate) {this.hourlyRate = hourlyRate;}
    
    public static int getHourlyCount() {return hourlyCount;}
    
    public String toString()
    {
        return super.toString() + ":" + getClass().getName() + "@" + position + ":" + String.format("%.2f", hourlyRate);
    }
    
    public boolean equals( Object o )
    {
        if ( !( o instanceof Hourly ) )
            return false;
        
        Hourly h = ( Hourly ) o;
        
        return super.equals( h )
                && position.equals( h.position )
                && hourlyRate == h.hourlyRate;
    } 
    
}
