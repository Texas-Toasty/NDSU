/**
 * Client
 * 
 * Demonstrates the functions of the Scores class
 * 
 * @author Reece Parry
 * @version 09/11/2025
 */
import java.util.Random;

public class Client {
    
    /**
     * The main method performs a sequence of actions:
     * - Create Scores(2)
     * - Populate with 16 random numbers from -10 to 10
     * - Prints the list, adds 3, removes a random number-
     * finds index 6, frequencies of the number, finds if the list-
     * contains -5, creates a second Scores and tests the equals method
     * 
     * @param args
     */
    
    public static void main(String[] args) {
        Random rand = new Random();
        
        System.out.println("1: Creating Scores with the initial capacity of 2");        
        Scores s = new Scores(2);
        
        System.out.println("\n2: Populating the Scores object with 16 random numbers between -10 and 10");
        for(int i = 0; i < 16; i++) {
            int r = rand.nextInt(21) - 10;
            s.add(r);
        }
        System.out.println("After population had been added " + s);
        
        System.out.println("\n3: Adding '3' to Scores");
        s.add(3);
        System.out.println("After adding 3: " + s);
        
        System.out.println("\n4: Removing a random value for Scores");
        int removedRandom = s.remove();
        System.out.println("Randomly removed value: " + removedRandom);
        System.out.println("Scores now is: " + s);
        
        System.out.println("\n5: Getting the value at index 6");
        int valueAtSix = s.get(6);
        System.out.println("Value at six: " + valueAtSix);
        
        System.out.println("\n6: Printing the frequency of the value at index 6");
        System.out.println("Frequency of " + valueAtSix + " at six: " + s.getFrequencyOf(valueAtSix));
        
        System.out.println("\n7: Removing the first occurrence of the value at index 6");
        s.remove(valueAtSix);
        System.out.println("Frequency of " + valueAtSix + " after removing: " + s.getFrequencyOf(valueAtSix));
        System.out.println("Scores now: " + s);
        
        System.out.println("\n8: Checking whether -5 is within Scores...");
        System.out.println("Contains -5: " + s.contains(-5));
        
        System.out.println("\n9: Creating a second instance of the Scores class and filling to the same size as the original list");
        Scores s2 = new Scores (2);
        while (s2.size() < s.size()) {
            s2.add(rand.nextInt(21) - 10);
        }
        System.out.println("New list: " + s2);
        
        System.out.println("Testing if the two random lists are equal");
        System.out.println("It is: " + s2.equals(s));
        
        System.out.println("Testing if the two lengths are equal");
        System.out.println("It is: " + (s.size() == s2.size()));
    }
    
}
