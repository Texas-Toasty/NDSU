/**
 *
 * @author Reece Parry
 * @version 09/11/2025
 *
 */
import java.util.Random;

public class Scores {
   
    private int[] list;
    private int size;
   
    /**
     * Default constructor, initializes the array length to 10.
     */
    
    public Scores () {
        this.list = new int[10];
        this.size = 0;
    }
   
    /**
    * Overloaded constructor, initializes internal array to given length.
     * @param initialCapacity
    */
    
    public Scores(int initialCapacity) {
        if(initialCapacity < 1) {
            initialCapacity = 10;
        }
        this.list = new int[initialCapacity];
        this.size = 0;
    }
   /**
    * Returns the current number of items stored
    * 
    * @return current size
    */
    public int size(){
        return this.size;
    }
   /**
    * Checks if the Scores object is empty
    * 
    * @return true if no items are stored in Scores, otherwise false
    */
    public boolean isEmpty() {
        return this.size == 0;
    }
   /**
    * Removes all numbers from the Scores object
    */
    public void clear(){
        this.size = 0;
    }
   /**
    * Counts how many times 'num' appears in Scores
    * @param num
    * @return frequency
    */
    public int getFrequencyOf(int num) {
        int count = 0;
        for (int i = 0; i < size; i++) {
            if(list[i] == num) count++;
        }
        return count;
    }
   /**
    * Tests to see if Scores contains a certain number
    * @param num
    * @return true if found, otherwise false
    */
    public boolean contains(int num) {
        for (int i = 0; i < size; i++) {
            if (list[i] == num) {
                return true;
            }
        }
        return false;
    }
   /**
    * Adds num to the next open spot in the array, if the array is full
    * it doubles the length
    * @param num value to add
    */
    public void add(int num) {
        if(size == list.length){
        int[] temp = new int[list.length * 2];
       
        for (int i = 0; i < list.length; i++) {
            temp[i] = list[i];
            }
            list = temp;
        }
        list[size] = num;
        size++;
    }
   /**
    * Removes the first occurrence of number num from the list
    * @param num value to remove
    */
    public void remove(int num) {
        int found = -1;
        for(int i = 0; i < size; i++) {
            if (list[i] == num) {
                found = i;
                break;
            }
        }
        if (found == -1) return;
        for (int i = found; i < size -1; i++) {
            list[i] = list [i+1];
        }
        size--;
    }
   /**
    * Removes and returns a random element from the list
    * Throws an IllegalStateException if called on any empty spots
    * @return removed value
    * @throws IllegalStateException
    */
    public int remove() {
        if (size == 0) {
            throw new IllegalStateException("The remove() method cannot be called on an empty list");
        }
        Random rand = new Random();
        int idx = rand.nextInt(size); // between 0 (inclusive) and size (exclusive)
        int removedValue = list[idx];
        for (int i = idx; i < size - 1; i++) {
            list[i] = list[i + 1];
        }
        size--;
        return removedValue;
    }
   /**
    * Returns the element at index i
    * If i is outside of the array's bounds, throws ArrayIndexOutOfBoundsException
    * @param i index to get
    * @return value at index i
    * @throws ArrayIndexOutOfBoundsException
    */
    public int get(int i) {
       if (i < 0 || i >= size) {
           throw new ArrayIndexOutOfBoundsException("Index " + i + " out of bounds for size " + size);
        }
       return list[i];
    }
   
     /**
     * Returns a readable string describing the Scores object.
     *
     * @return string containing size and elements in order
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Scores(size=").append(size).append(", list=[");
        for (int i = 0; i < size; i++) {
            sb.append(list[i]);
            if (i < size - 1) sb.append(", ");
        }
        sb.append("])");
        return sb.toString();
    }

    /**
     * Compares this Scores object to another for exact equality:
     * same size and same values in same order.
     *
     * @param o the object to compare
     * @return true if exactly equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Scores)) return false;
        Scores other = (Scores) o;
        if (this.size != other.size) return false;
        for (int i = 0; i < size; i++) {
            if (this.list[i] != other.list[i]) return false;
        }
        return true;
    }
}