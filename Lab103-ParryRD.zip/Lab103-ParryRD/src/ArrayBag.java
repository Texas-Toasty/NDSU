
/**
 *
 * @author Reece Parry
 * @version 09/19/2025
 */
import java.util.Random;

public class ArrayBag<E> implements BagInterface<E> {

    private E[] list;   // generic array for elements
    private int size;   // current number of items in the bag

    /**
     * Default constructor, initializes the array length to 10.
     */
    @SuppressWarnings("unchecked")
    public ArrayBag() {
        this.list = (E[]) new Object[10];
        this.size = 0;
    }

    /**
     * Overloaded constructor, initializes internal array to given length.
     *
     * @param initialCapacity
     */
    @SuppressWarnings("unchecked")
    public ArrayBag(int initialCapacity) {
        if (initialCapacity < 1) {
            initialCapacity = 10;
        }
        this.list = (E[]) new Object[initialCapacity];
        this.size = 0;
    }

    /**
     * Returns the current number of items stored
     *
     * @return
     */
    @Override
    public int size() {
        return this.size;
    }

    /**
     * Checks if the bag is empty
     *
     * @return
     */
    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }

    /**
     * Removes all elements from the bag
     */
    @Override
    public void clear() {
        this.size = 0;
    }

    /**
     * Counts how many times 'e' appears in the bag
     *
     * @param e
     * @return
     */
    @Override
    public int getFrequencyOf(E e) {
        int count = 0;
        for (int i = 0; i < size; i++) {
            if (list[i].equals(e)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Tests to see if the bag contains a certain element
     *
     * @param e
     * @return
     */
    @Override
    public boolean contains(E e) {
        for (int i = 0; i < size; i++) {
            if (list[i].equals(e)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adds an element to the bag, doubling array length if full
     *
     * @param e
     */
    @Override
    @SuppressWarnings("unchecked")
    public void add(E e) {
        if (size == list.length) {
            E[] temp = (E[]) new Object[list.length * 2];
            for (int i = 0; i < list.length; i++) {
                temp[i] = list[i];
            }
            list = temp;
        }
        list[size] = e;
        size++;
    }

    /**
     * Removes the first occurrence of e from the bag, returns removed value or
     * null
     *
     * @param e
     * @return
     */
    @Override
    public E remove(E e) {
        int found = -1;
        for (int i = 0; i < size; i++) {
            if (list[i].equals(e)) {
                found = i;
                break;
            }
        }
        if (found == -1) {
            return null;
        }

        E removed = list[found];
        for (int i = found; i < size - 1; i++) {
            list[i] = list[i + 1];
        }
        size--;
        return removed;
    }

    /**
     * Removes and returns a random element from the bag
     *
     * @return
     */
    @Override
    public E remove() {
        if (size == 0) {
            return null;
        }
        Random rand = new Random();
        int idx = rand.nextInt(size);
        E removedValue = list[idx];
        for (int i = idx; i < size - 1; i++) {
            list[i] = list[i + 1];
        }
        size--;
        return removedValue;
    }

    /**
     * Returns the element at index i
     *
     * @param i
     * @return
     */
    @Override
    public E get(int i) {
        if (i < 0 || i >= size) {
            throw new ArrayIndexOutOfBoundsException("Index " + i + " out of bounds for size " + size);
        }
        return list[i];
    }

    /**
     * Returns a readable string describing the bag
     *
     * @return
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bag(size=").append(size).append(", list=[");
        for (int i = 0; i < size; i++) {
            sb.append(list[i]);
            if (i < size - 1) {
                sb.append(", ");
            }
        }
        sb.append("])");
        return sb.toString();
    }

    /**
     * Compares this bag with another object to check for equality Two ArrayBags
     * are equal if they are the same size with the same corresponding entries
     *
     * @param o the object to compare with
     * @return true if the bags are equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ArrayBag)) {
            return false;
        }
        ArrayBag<?> other = (ArrayBag<?>) o;
        if (this.size != other.size) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (!this.list[i].equals(other.list[i])) {
                return false;
            }
        }
        return true;
    }
}
