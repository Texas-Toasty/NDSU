
/**
 *
 * @author Reece Parry
 * @version 09/17/2025
 */
public interface BagInterface<E> {

    int size();                 // returns a count of items in the bag

    boolean isEmpty();          // checks if the bags is empty, returns true when empty

    void clear();               // removes all the items from the bag

    int getFrequencyOf(E e);    // returns a count the number of times an item, e, exists in the bag

    boolean contains(E e);      // tests whether the bag contains the item e. Returns true when e is contained in the bag

    void add(E e);              // adds item, e, to the "next available" position in the bag

    E remove(E e);              // removes the first occurrence of the item e in the bag. Returns null if e is not in the bag or if called on an empty bag

    E remove();                 // method that removes a random entry from the bag. Returns the removed entry. Returns null if the bag is empty

    E get(int i);               // that returns the element at the i^th position in the bag. Throws an index out of bounds entry if passed an invalid index

    String toString();          // returns a String of the contents of the bag

    boolean equals(Object o);   // returns a true if the parameter o exactly mathces the contents of the bag

}
