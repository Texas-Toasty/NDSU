
/**
 * Client class demonstrates the functionality of the ArrayBag and LinkedBag classes
 *
 * @author Reece Parry
 * @version 09/19/2025
 */
public class Client {

    public static void main(String[] args) {

        ArrayBag<Player> mensTeam = new ArrayBag<>(2);

        mensTeam.add(new Player("Joey Smith", "Quarterback", 12));
        mensTeam.add(new Player("Jerome Moody", "Linebacker", 55));
        mensTeam.add(new Player("Jacob Needly", "Kicker", 11));
        mensTeam.add(new Player("Joshua Franklin", "Cornerback", 8));
        mensTeam.add(new Player("Jacoby Myers", "Center", 68));
        mensTeam.add(new Player("Josh Jacobson", "Running Back", 22));
        mensTeam.add(new Player("Jackson Wilson", "Safety", 35));
        mensTeam.add(new Player("Jim Wilder", "Wide Reciever", 10));

        System.out.println("Men's football team: " + mensTeam);

        Player removePlayer = mensTeam.remove();

        System.out.println("Removed player: " + removePlayer);
        System.out.println("Team after removal: " + mensTeam);

        Player fifthPlayer = mensTeam.get(4);
        System.out.println("Fifth player in the list: " + fifthPlayer);

        mensTeam.add(new Player("Jake Nealson", "Tight End", 88));
        System.out.println("Men's team after adding a new player: " + mensTeam);

        mensTeam.remove(fifthPlayer);
        System.out.println("Men's team after removing fifth player: " + mensTeam);

        ArrayBag<String> courses = new ArrayBag<>(5);

        courses.add("CSCI 161");
        courses.add("CSCI 222");
        courses.add("MATH 129");
        courses.add("ENG 320");
        courses.add("STAT 367");

        System.out.println(courses);

        String removedCourse = courses.remove();
        System.out.println("Removed random course: " + removedCourse);
        System.out.println("Courses list" + courses);

        LinkedBag<Player> womensTeam = new LinkedBag<>();

        womensTeam.add(new Player("Rachel Johnson", "Center", 22));
        womensTeam.add(new Player("Roxie Johanna", "Forward", 18));
        womensTeam.add(new Player("Teagen Mouser", "Point Guard", 66));
        womensTeam.add(new Player("Maria Larson", "Point Guard", 55));
        womensTeam.add(new Player("Laney Wilson", "Center", 90));
        womensTeam.add(new Player("Natalie Langly", "Shooting Guard", 11));
        womensTeam.add(new Player("Katelyn Clark", "Center", 49));
        womensTeam.add(new Player("Rose Coleman", "Power Forward", 17));

        System.out.println("Womens basketball team: " + womensTeam);

        Player removedPlayer1 = womensTeam.remove();
        System.out.println("Removed" + removedPlayer1);
        System.out.println("Womens team after removal: " + womensTeam);

        Player fifthPlayer1 = womensTeam.get(4);
        System.out.println("Fifth player on the team: " + fifthPlayer1);

        womensTeam.add(new Player("Yelena Williams", "Center", 20));
        System.out.println("Womens team after adding a player: " + womensTeam);

        womensTeam.remove(fifthPlayer1);
        System.out.println("Womens team after removing " + fifthPlayer1 + " " + womensTeam);
    }

}
