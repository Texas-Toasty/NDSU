
/**
 *
 * @author Reece Parry
 * @version 09/19/2025
 *
 * LinkedBag implements BagInterface<E> using an internal SinglyLinkedList<E>.
 * This class does not maintain its own size variable — it delegates size
 * bookkeeping to the SinglyLinkedList.
 */
import java.util.Objects;
import java.util.Random;

public class LinkedBag<E> implements BagInterface<E> {

    private SinglyLinkedList<E> list;

    /**
     * Default constructor initializes list to an empty singly linked list
     */
    public LinkedBag() {
        list = new SinglyLinkedList<>();
    }

    /**
     * Overload constructor refers back to the default constructor
     *
     * @param capacity
     */
    public LinkedBag(int capacity) {
        this();
    }

    @Override
    public int size() {
        return list.size();
    }

    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    @Override
    public void clear() {
        list.clear();
    }

    @Override
    public int getFrequencyOf(E e) {
        int count = 0;
        int n = list.size();
        for (int i = 0; i < n; i++) {
            E current = list.get(i);
            if (Objects.equals(current, e)) {
                count++;
            }
        }
        return count;
    }

    @Override
    public boolean contains(E e) {
        return list.indexOf(e) != -1;
    }

    @Override
    public void add(E e) {
        list.addLast(e);
    }

    @Override
    public E remove(E e) {
        int idx = list.indexOf(e);
        if (idx == -1) {
            return null;
        }
        return list.removeAt(idx);
    }

    @Override
    public E remove() {
        int n = list.size();
        if (n == 0) {
            return null;
        }
        Random rnd = new Random();
        int idx = rnd.nextInt(n);
        return list.removeAt(idx);
    }

    @Override
    public E get(int i) {
        return list.get(i);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bag(size=").append(size()).append(", list=");
        sb.append(list.toString());
        sb.append(")");
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof LinkedBag)) {
            return false;
        }
        LinkedBag<?> other = (LinkedBag<?>) o;
        if (this.size() != other.size()) {
            return false;
        }
        int n = this.size();
        for (int i = 0; i < n; i++) {
            Object a = this.get(i);
            Object b = other.get(i);
            if (!Objects.equals(a, b)) {
                return false;
            }
        }
        return true;
    }

    public class SinglyLinkedList<E> {

        //------------ nested Node class ---------
        private static class Node<E> {

            private final E element;
            private Node<E> next;

            public Node(E e, Node<E> n) {
                element = e;
                next = n;
            }

            public E getElement() {
                return element;
            }

            public Node<E> getNext() {
                return next;
            }

            public void setNext(Node<E> n) {
                next = n;
            }
        } //---------- end of nested Node class ----------

        // Instance variables of the SinglyLinkedList
        private Node<E> head = null;        // head node of the list (or null if empty)
        private Node<E> tail = null;        // last node of the list (or null if empty)
        private int size = 0;               // number of nodes in the list

        public SinglyLinkedList() {
        }        // constructs an initially empty list

        // access methods
        public int size() {
            return size;
        }

        public boolean isEmpty() {
            return size == 0;
        }

        public E first() {                 // returns (but does not remove) the first element
            if (isEmpty()) {
                return null;
            }
            return head.getElement();
        }

        public E last() {                  // returns (but does not remove) the last element
            if (isEmpty()) {
                return null;
            }
            return tail.getElement();
        }

        // update methods
        public void addFirst(E e) {         // adds element e to the front of the list
            head = new Node<>(e, head);     // create and link a new node
            if (size == 0) {
                tail = head;                // special case: new node becomes tail also
            }
            size++;
        }

        public void addLast(E e) {          // adds element e to the end of the list
            Node<E> newest = new Node<>(e, null);   // node will eventually become the tail
            if (isEmpty()) {
                head = newest;              // special case: previously empty list
            } else {
                tail.setNext(newest);       // new node after existing tail
            }
            tail = newest;                  // new node becomes the tail
            size++;
        }

        public E removeFirst() {            // removes and returns the first element
            if (isEmpty()) {
                return null;     // nothing to remove
            }
            E answer = head.getElement();
            head = head.getNext();          // will become null if list had only one node
            size--;
            if (size == 0) {
                tail = null;                // special case as list is now empty
            }
            return answer;
        }

        public void clear() {
            head = null;
            tail = null;
            size = 0;
        }

        public int indexOf(E e) {
            Node<E> curr = head;
            int idx = 0;
            while (curr != null) {
                if (Objects.equals(curr.getElement(), e)) {
                    return idx;
                }
                curr = curr.getNext();
                idx++;
            }
            return -1;
        }

        public E get(int index) {
            if (index < 0 || index >= size) {
                throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
            }
            Node<E> curr = head;
            for (int i = 0; i < index; i++) {
                curr = curr.getNext();
            }
            return curr.getElement();
        }

        public E removeAt(int index) {
            if (index < 0 || index >= size) {
                throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
            }
            if (index == 0) {
                return removeFirst();
            }

            Node<E> prev = head;
            for (int i = 0; i < index - 1; i++) {
                prev = prev.getNext();
            }
            Node<E> target = prev.getNext();
            E result = target.getElement();
            prev.setNext(target.getNext());
            size--;
            if (target == tail) {
                tail = prev;
            }
            return result;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            Node<E> curr = head;
            while (curr != null) {
                sb.append(curr.getElement());
                if (curr.getNext() != null) {
                    sb.append(", ");
                }
                curr = curr.getNext();
            }
            sb.append("]");
            return sb.toString();
        }
    }
}
