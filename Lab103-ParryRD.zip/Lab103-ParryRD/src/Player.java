
/**
 * Player class represents a player with a name, position, and jersey number
 *
 * @author Reece Parry
 * @version 09/19/2025
 */
public class Player {

    private String name;
    private String position;
    private int jerseyNumber;

    /**
     * Default constructor
     */
    public Player() {
        this.name = "";
        this.position = "";
        this.jerseyNumber = 0;
    }

    /**
     * Overload constructor
     *
     * @param name
     * @param position
     * @param jerseyNumber
     */
    public Player(String name, String position, int jerseyNumber) {
        this.name = name;
        this.position = position;
        this.jerseyNumber = jerseyNumber;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public int getJerseyNumber() {
        return jerseyNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setJerseyNumber(int jerseyNumber) {
        this.jerseyNumber = jerseyNumber;
    }

    @Override
    public String toString() {
        return "Player{name: " + name + ", position: " + position + ", jerseyNumber: " + jerseyNumber + "}";
    }

    /**
     * Compares this player to another object to check for equality Two players
     * are equal if all three factors are exactly the same
     *
     * @param o comparison object
     * @return true if the players are equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Player)) {
            return false;
        }
        Player p = (Player) o;

        return jerseyNumber == p.jerseyNumber
                && (name != null ? name.equals(p.name) : p.name == null)
                && (position != null ? position.equals(p.position) : p.position == null);

    }

}
