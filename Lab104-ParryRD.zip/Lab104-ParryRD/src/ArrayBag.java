
/**
 *
 * @author Reece Parry
 * @version 09/26/2025
 */
import java.util.Random;

public class ArrayBag<E> {

    private E[] list;   // internal generic array for elements
    private int size;   // current number of items in the bag

    /**
     * Default constructor Initializes the bag with a capacity of 10
     */
    @SuppressWarnings("unchecked")
    public ArrayBag() {
        this.list = (E[]) new Object[10];
        this.size = 0;
    }

    /**
     * Overload constructor Initializes internal array to given length
     *
     * @param initialCapacity the starting capacity of the bag (must be >= 1,
     * otherwise defaults to 10)
     */
    @SuppressWarnings("unchecked")
    public ArrayBag(int initialCapacity) {
        if (initialCapacity < 1) {
            initialCapacity = 10;
        }
        this.list = (E[]) new Object[initialCapacity];
        this.size = 0;
    }

    /**
     * Returns the current number of items stored in the bag
     *
     * @return the number of items
     */
    public int size() {
        return this.size;
    }

    /**
     * Checks if the bag is empty
     *
     * @return true if the bag is empty, false otherwise
     */
    public boolean isEmpty() {
        return this.size == 0;
    }

    /**
     * Removes all elements from the bag
     */
    public void clear() {
        this.size = 0;
    }

    /**
     * Counts how many times the given element appears in the bag
     *
     * @param e the element to search for
     * @return the frequency of the element in the bag
     */
    public int getFrequencyOf(E e) {
        int count = 0;
        for (int i = 0; i < size; i++) {
            if (list[i].equals(e)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Tests to see if the bag contains a certain element.
     *
     * @param e the element to search for
     * @return true if the bag contains the element, false otherwise
     */
    public boolean contains(E e) {
        for (int i = 0; i < size; i++) {
            if (list[i].equals(e)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adds an element to the bag, doubling array length if full
     *
     * @param e the element to add
     */
    @SuppressWarnings("unchecked")
    public void add(E e) {
        if (size == list.length) {
            E[] temp = (E[]) new Object[list.length * 2];
            for (int i = 0; i < list.length; i++) {
                temp[i] = list[i];
            }
            list = temp;
        }
        list[size] = e;
        size++;
    }

    /**
     * Removes the first occurrence of the given element from the bag
     *
     * @param e the element to remove
     * @return the removed element if found, or null otherwise
     */
    public E remove(E e) {
        int found = -1;
        for (int i = 0; i < size; i++) {
            if (list[i].equals(e)) {
                found = i;
                break;
            }
        }
        if (found == -1) {
            return null;
        }

        E removed = list[found];
        for (int i = found; i < size - 1; i++) {
            list[i] = list[i + 1];
        }
        size--;
        return removed;
    }

    /**
     * Removes and returns a random element from the bag.
     *
     * @return the removed element, or null if the bag is empty
     */
    public E remove() {
        if (size == 0) {
            return null;
        }
        Random rand = new Random();
        int idx = rand.nextInt(size);
        E removedValue = list[idx];
        for (int i = idx; i < size - 1; i++) {
            list[i] = list[i + 1];
        }
        size--;
        return removedValue;
    }

    /**
     * Returns the element at the given index.
     *
     * @param i the index of the element
     * @return the element at index i
     * @throws ArrayIndexOutOfBoundsException if index is invalid
     */
    public E get(int i) {
        if (i < 0 || i >= size) {
            throw new ArrayIndexOutOfBoundsException("Index " + i + " out of bounds for size " + size);
        }
        return list[i];
    }

    /**
     * Adds element without additional checks or output.
     *
     * @param e the element to add
     */
    @SuppressWarnings("unchecked")
    public void addTest(E e) {
        if (size == list.length) {
            E[] temp = (E[]) new Object[list.length * 2];
            for (int i = 0; i < list.length; i++) {
                temp[i] = list[i];
            }
            list = temp;
        }
        list[size] = e;
        size++;
    }

    /**
     * Removes the last element in O(1).
     *
     * @return the removed element, or null if bag is empty
     */
    public E removeTest() {
        if (size == 0) {
            return null;
        }
        E result = list[size - 1];
        list[size - 1] = null;
        size--;
        return result;
    }

    /**
     * Returns a readable string with the bag contents.
     *
     * @return a string representation of the bag
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bag(size=").append(size).append(", list=[");
        for (int i = 0; i < size; i++) {
            sb.append(list[i]);
            if (i < size - 1) {
                sb.append(", ");
            }
        }
        sb.append("])");
        return sb.toString();
    }

    /**
     * Compares this bag with another object to check for equality. Two
     * ArrayBags are equal if they have the same size and corresponding entries
     * are equal
     *
     * @param o the object to compare with
     * @return true if the bags are equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ArrayBag)) {
            return false;
        }
        ArrayBag<?> other = (ArrayBag<?>) o;
        if (this.size != other.size) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (!this.list[i].equals(other.list[i])) {
                return false;
            }
        }
        return true;
    }
}
