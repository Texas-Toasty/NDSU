
/**
 *
 * @author Reece Parry
 * @version 09/26/2025
 */
public class Client {

    public static void main(String[] args) {

        int[] Ns = {10, 100, 1_000, 10_000, 100_000};

        long[][] results = new long[Ns.length][3];

        for (int i = 0; i < Ns.length; i++) {
            int N = Ns[i];
            results[i][0] = N;

            ArrayBag<Integer> arrayBag = new ArrayBag<>(N);
            long start = System.nanoTime();
            for (int j = 0; j < N; j++) {
                arrayBag.add(j);
            }
            for (int j = 0; j < N; j++) {
                arrayBag.remove();
            }
            long end = System.nanoTime();
            results[i][1] = end - start;

            LinkedBag<Integer> linkedBag = new LinkedBag<>(N);
            start = System.nanoTime();
            for (int j = 0; j < N; j++) {
                linkedBag.add(j);
            }
            for (int j = 0; j < N; j++) {
                linkedBag.remove();
            }
            end = System.nanoTime();
            results[i][2] = end - start;
        }

        printTable(results);

    }

    private static String formatNumber(long n) {
        String s = Long.toString(n);
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            sb.insert(0, s.charAt(i));
            count++;
            if (count == 3 && i > 0) {
                sb.insert(0, ',');
                count = 0;
            }
        }
        return sb.toString();
    }

    private static void printTable(long[][] results) {

        String[] headers = {"N", "Array Time", "Linked Time"};

        // Find widths
        int[] widths = new int[headers.length];
        for (long[] row : results) {
            for (int j = 0; j < row.length; j++) {
                String val = formatNumber(row[j]);
                if (val.length() > widths[j]) {
                    widths[j] = val.length();
                }
            }
        }

        // Print seperator
        printSeparator(widths);

        // Print headers
        System.out.printf("|");
        for (int i = 0; i < headers.length; i++) {
            System.out.printf(" %-" + widths[i] + "s |", headers[i]);
        }
        System.out.printf("%n");
        printSeparator(widths);

        // Print rows
        for (long[] row : results) {
            System.out.printf("|");
            for (int j = 0; j < row.length; j++) {
                String val = formatNumber(row[j]);
                System.out.printf(" %" + widths[j] + "s |", val);
            }
            System.out.printf("%n");
            printSeparator(widths);
        }
    }

    private static void printSeparator(int[] widths) {
        System.out.printf("+");
        for (int w : widths) {
            for (int i = 0; i < w + 2; i++) {
                System.out.printf("-");
            }
            System.out.printf("+");
        }
        System.out.printf("%n");
    }

}
