
/**
 * LinkedBag implements a bag using a singly linked list as its internal storage.
 *
 * @param <E> the type of elements stored in this bag
 *
 * @author Reece Parry
 * @version 09/26/2025
 */
import java.util.Objects;
import java.util.Random;

public class LinkedBag<E> {

    private SinglyLinkedList<E> list;

    /**
     * Default constructor Initializes the bag with an empty singly linked list
     */
    public LinkedBag() {
        list = new SinglyLinkedList<>();
    }

    /**
     * Overloaded constructor Capacity is ignored since linked lists are dynamic
     *
     * @param capacity an initial capacity value (not used)
     */
    public LinkedBag(int capacity) {
        this();
    }

    /**
     * Returns the current number of items stored in the bag
     *
     * @return the number of items
     */
    public int size() {
        return list.size();
    }

    /**
     * Checks if the bag is empty
     *
     * @return true if empty, false otherwise
     */
    public boolean isEmpty() {
        return list.isEmpty();
    }

    /**
     * Removes all elements from the bag
     */
    public void clear() {
        list.clear();
    }

    /**
     * Counts how many times the given element appears in the bag
     *
     * @param e the element to search for
     * @return the frequency of the element in the bag
     */
    public int getFrequencyOf(E e) {
        int count = 0;
        int n = list.size();
        for (int i = 0; i < n; i++) {
            E current = list.get(i);
            if (Objects.equals(current, e)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Tests to see if the bag contains a certain element
     *
     * @param e the element to search for
     * @return true if the element is in the bag, false otherwise
     */
    public boolean contains(E e) {
        return list.indexOf(e) != -1;
    }

    /**
     * Adds an element to the bag
     *
     * @param e the element to add
     */
    public void add(E e) {
        list.addLast(e);
    }

    /**
     * Removes the first occurrence of the given element from the bag
     *
     * @param e the element to remove
     * @return the removed element, or null if not found
     */
    public E remove(E e) {
        int idx = list.indexOf(e);
        if (idx == -1) {
            return null;
        }
        return list.removeAt(idx);
    }

    /**
     * Removes and returns a random element from the bag
     *
     * @return the removed element, or null if the bag is empty
     */
    public E remove() {
        int n = list.size();
        if (n == 0) {
            return null;
        }
        Random rnd = new Random();
        int idx = rnd.nextInt(n);
        return list.removeAt(idx);
    }

    /**
     * Returns the element at the given index
     *
     * @param i the index of the element
     * @return the element at the index
     * @throws IndexOutOfBoundsException if index is invalid
     */
    public E get(int i) {
        return list.get(i);
    }

    /**
     * Adds an element to the front of the list
     *
     * @param e the element to add
     */
    public void addTest(E e) {
        list.addFirst(e);
    }

    /**
     * Removes the first element of the list
     *
     * @return the removed element, or null if empty
     */
    public E removeTest() {
        return list.removeFirst();
    }

    /**
     * Returns a string with the bag contents
     *
     * @return a string representation of the bag
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bag(size=").append(size()).append(", list=");
        sb.append(list.toString());
        sb.append(")");
        return sb.toString();
    }

    /**
     * Compares this bag with another object for equality. Two LinkedBags are
     * equal if they have the same size and corresponding elements are equal
     *
     * @param o the object to compare with
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof LinkedBag)) {
            return false;
        }
        LinkedBag<?> other = (LinkedBag<?>) o;
        if (this.size() != other.size()) {
            return false;
        }
        int n = this.size();
        for (int i = 0; i < n; i++) {
            Object a = this.get(i);
            Object b = other.get(i);
            if (!Objects.equals(a, b)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Inner class implementing a basic singly linked list with head/tail
     * pointers and integer size.
     *
     * @param <E> the type of elements stored in the list
     */
    public class SinglyLinkedList<E> {

        //------------ nested Node class ---------
        private static class Node<E> {

            private final E element; // element stored in this node
            private Node<E> next;    // reference to next node

            /**
             * Creates a new node.
             *
             * @param e the element to store
             * @param n the next node
             */
            public Node(E e, Node<E> n) {
                element = e;
                next = n;
            }

            /**
             * @return the element stored in the node
             */
            public E getElement() {
                return element;
            }

            /**
             * @return the next node reference
             */
            public Node<E> getNext() {
                return next;
            }

            /**
             * Sets the next node reference.
             */
            public void setNext(Node<E> n) {
                next = n;
            }
        }

        // Instance variables
        private Node<E> head = null;  // first node
        private Node<E> tail = null;  // last node
        private int size = 0;         // number of nodes

        /**
         * Constructs an initially empty list
         */
        public SinglyLinkedList() {
        }

        /**
         * @return the number of nodes in the list
         */
        public int size() {
            return size;
        }

        /**
         * @return true if the list is empty
         */
        public boolean isEmpty() {
            return size == 0;
        }

        /**
         * Returns (but does not remove) the first element
         *
         * @return the first element, or null if empty
         */
        public E first() {
            if (isEmpty()) {
                return null;
            }
            return head.getElement();
        }

        /**
         * Returns (but does not remove) the last element
         *
         * @return the last element, or null if empty
         */
        public E last() {
            if (isEmpty()) {
                return null;
            }
            return tail.getElement();
        }

        /**
         * Adds an element to the front of the list
         *
         * @param e the element to add
         */
        public void addFirst(E e) {
            head = new Node<>(e, head);
            if (size == 0) {
                tail = head;
            }
            size++;
        }

        /**
         * Adds an element to the end of the list
         *
         * @param e the element to add
         */
        public void addLast(E e) {
            Node<E> newest = new Node<>(e, null);
            if (isEmpty()) {
                head = newest;
            } else {
                tail.setNext(newest);
            }
            tail = newest;
            size++;
        }

        /**
         * Removes and returns the first element of the list
         *
         * @return the removed element, or null if empty
         */
        public E removeFirst() {
            if (isEmpty()) {
                return null;
            }
            E answer = head.getElement();
            head = head.getNext();
            size--;
            if (size == 0) {
                tail = null;
            }
            return answer;
        }

        /**
         * Clears the list
         */
        public void clear() {
            head = null;
            tail = null;
            size = 0;
        }

        /**
         * Finds the index of the first occurrence of the given element
         *
         * @param e the element to search for
         * @return index of the element, or -1 if not found
         */
        public int indexOf(E e) {
            Node<E> curr = head;
            int idx = 0;
            while (curr != null) {
                if (Objects.equals(curr.getElement(), e)) {
                    return idx;
                }
                curr = curr.getNext();
                idx++;
            }
            return -1;
        }

        /**
         * Returns the element at the given index
         *
         * @param index the index
         * @return the element at the index
         * @throws IndexOutOfBoundsException if index is invalid
         */
        public E get(int index) {
            if (index < 0 || index >= size) {
                throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
            }
            Node<E> curr = head;
            for (int i = 0; i < index; i++) {
                curr = curr.getNext();
            }
            return curr.getElement();
        }

        /**
         * Removes and returns the element at the given index
         *
         * @param index the index to remove
         * @return the removed element
         * @throws IndexOutOfBoundsException if index is invalid
         */
        public E removeAt(int index) {
            if (index < 0 || index >= size) {
                throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
            }
            if (index == 0) {
                return removeFirst();
            }

            Node<E> prev = head;
            for (int i = 0; i < index - 1; i++) {
                prev = prev.getNext();
            }
            Node<E> target = prev.getNext();
            E result = target.getElement();
            prev.setNext(target.getNext());
            size--;
            if (target == tail) {
                tail = prev;
            }
            return result;
        }

        /**
         * Returns a string representation of the list
         *
         * @return string in the form [a, b, c]
         */
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            Node<E> curr = head;
            while (curr != null) {
                sb.append(curr.getElement());
                if (curr.getNext() != null) {
                    sb.append(", ");
                }
                curr = curr.getNext();
            }
            sb.append("]");
            return sb.toString();
        }
    }
}
