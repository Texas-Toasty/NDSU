import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 *
 * @author Reece Parry
 * @version 10/09/2025
 */
public class Client {

    public static void main(String[] args) throws FileNotFoundException {

        Scanner input = new Scanner(System.in);

        boolean again;
        do {
            again = false;
            System.out.println("Welcome to the Calculator/Finder Program!");
            System.out.println("------------------------------");
            
            int choice = 0;
            boolean validChoice = false;
            
            while(!validChoice){
            System.out.println("1. Compute a Harmonic number");
            System.out.println("2. Compute a summation");
            System.out.println("3. Find a file");
            System.out.println("Enter your choice 1-3: ");
            
            if(input.hasNextInt()) {
                choice = input.nextInt();
                input.nextLine();
                if (choice >= 1 && choice <= 3) {validChoice = true;}
                else {System.out.println("Invalid choice, please enter a number between 1 and 3.");}
            }
            else {System.out.println("Invalid input, please enter a number between 1 and 3"); input.nextLine();}

            switch (choice) {
                case 1 -> {
                    int n = getPositiveInt(input, "Enter n for harmonic number: ");
                    System.out.printf("Harmonic number H(%d) = %.4f%n", n, Recursion.harmonicAlgorithm(n));
                }
                case 2 -> {
                    int n = getPositiveInt(input, "Enter n for sum: ");
                    System.out.printf("Sum from 1 to %d = %d%n", n, Recursion.sumUpTo(n));
                }
                case 3 -> {
                    System.out.println("Enter the filename you are looking for: ");
                    String fileName = input.nextLine();
                    System.out.println("Enter the starting directory: ");
                    String startPath = input.nextLine();

                    File startDirectory = new File(startPath);
                    if (!startDirectory.exists() || !startDirectory.isDirectory()) {
                        System.out.println("Invalid directory, Would you like to try again? (y/n)");
                        if (input.nextLine().equalsIgnoreCase("y")) again = true;
                    } else {
                        System.out.println("Searching for file named \"" + fileName + "\"...");
                        try {
                            Recursion.findFile(fileName, startPath);
                        } catch (FileNotFoundException e) {
                            System.out.println("File not found.");
                            System.out.println("Would you like to try again? (y/n): ");
                            if (input.nextLine().equalsIgnoreCase("y")) again = true;
                        }
                    }
                }
            }

            if (!again) {
                System.out.println("\nWould you like to run another algorithm? (y/n): ");
                again = input.nextLine().equalsIgnoreCase("y");
            }
            }
        } while (again);

        System.out.println("Goodbye!");
        input.close();
    }

    private static int getPositiveInt(Scanner input, String prompt) {
        int n;
        while (true) {
            System.out.println(prompt);
            if (input.hasNextInt()) {
                n = input.nextInt();
                input.nextLine();
                if (n > 0) return n;
            } else {
                input.nextLine();
            }
            System.out.println("Error: Please enter an integer greater than 0.");
        }
    }
}
