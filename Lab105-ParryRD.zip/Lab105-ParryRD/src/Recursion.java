
import java.io.File;
import java.io.FileNotFoundException;

/**
 *
 * @author Reece Parry
 * @version 10/08/2025
 */
public class Recursion {

    public static double harmonicAlgorithm(int n) {
        if (n == 1) {
            return 1.0;
        }
        return 1.0 / n + harmonicAlgorithm(n - 1);
    }

    public static int sumUpTo(int n) {
        if (n == 1) {
            return 1;
        }
        return n + sumUpTo(n - 1);
    }

    public static void findFile(String targetFileName, String startPath) throws FileNotFoundException {
        File directory = new File(startPath);

        if (!directory.exists()) {            
            System.out.println("Error: The path does not exist.");
            return;
        }

        if (!directory.isDirectory()) {
            System.out.println("Error: The provided path is not a directory.");
            return;
        }

        boolean found = searchFile(targetFileName, directory);

        if (!found) {
            throw new FileNotFoundException("File \"" + targetFileName + "\" not found in " + startPath);
        }
    }
    
    private static boolean searchFile(String targetFileName, File directory) {
        boolean found = false;

        File[] files = directory.listFiles();
        if (files == null) return false;

        for (File file : files) {
            if (file.isFile() && file.getName().equalsIgnoreCase(targetFileName)) {
                System.out.println("Found: " + file.getAbsolutePath());
                found = true;
            } else if (file.isDirectory()) {
                if (searchFile(targetFileName, file)) {
                    found = true;
                }
            }
        }

        return found;
    }
}