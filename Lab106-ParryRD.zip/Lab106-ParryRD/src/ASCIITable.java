
/**
 *
 * @author Reece Parry
 * @version 10/17/2025
 */
public class ASCIITable {

    private String[] headers;
    private String[][] rows;
    private int rowCount;
    private int cols;

    /**
     * Constructs a new {@code ASCIITable} with a specified maximum number of rows
     * and a fixed number of columns.
     *
     * @param maxRows the maximum number of rows this table can hold
     * @param cols the number of columns in the table
     */
    public ASCIITable(int maxRows, int cols) {
        this.cols = cols;
        this.rows = new String[maxRows][cols];
        this.rowCount = 0;
    }

    /**
     * Sets the header row for the table. Headers are displayed at the top
     * and use the same alignment and padding as data rows.
     *
     * @param headers an array of strings representing column headers
     */
    public void setHeaders(String[] headers) {
        this.headers = headers;
    }

    /**
     * Adds a new row of string values to the table.
     * If the maximum number of rows has already been reached,
     * the new row will be ignored.
     *
     * @param row an array of strings representing a single row of table data
     */
    public void addRow(String[] row) {
        if (rowCount < rows.length) {
            rows[rowCount] = row;
            rowCount++;
        }
    }

    /**
     * Calculates the width of each column based on the widest cell content
     * (including headers), and adds 4 extra spaces for padding.
     *
     * @return an integer array containing the computed width of each column
     */
    private int[] calculateWidths() {
        int[] widths = new int[cols];

        // Headers
        if (headers != null) {
            for (int i = 0; i < cols; i++) {
                widths[i] = headers[i].length();
            }
        }

        // Rows
        for (int r = 0; r < rowCount; r++) {
            for (int c = 0; c < cols; c++) {
                String val = (rows[r][c] == null) ? "" : rows[r][c];
                if (val.length() > widths[c]) widths[c] = val.length();
            }
        }

        // Add 4 total padding chars (2 left, 2 right)
        for (int i = 0; i < cols; i++) widths[i] += 4;

        return widths;
    }

    /**
     * Prints a horizontal divider line based on the current column widths.
     * The line uses '+' and '-' characters to separate table rows.
     *
     * @param widths an array representing the width of each column
     */
    private void printLine(int[] widths) {
        System.out.print("+");
        for (int w : widths) {
            for (int i = 0; i < w; i++) System.out.print("-");
            System.out.print("+");
        }
        System.out.println();
    }

    /**
     * Prints a single row of the table with right-aligned cell content.
     *
     * @param row the array of cell values to be printed
     * @param widths an array representing the width of each column
     */
    private void printRow(String[] row, int[] widths) {
        System.out.print("|");
        for (int i = 0; i < widths.length; i++) {
            String val = (i < row.length && row[i] != null) ? row[i] : "";
            int colWidth = widths[i] - 4;
            System.out.printf("  %" + colWidth + "s  |", val);
        }
        System.out.println();
    }

    /**
     * Prints the entire ASCII table to the terminal, including headers,
     * data rows, and border lines.
     */
    public void printTable() {
        int[] widths = calculateWidths();
        printLine(widths);

        if (headers != null) {
            printRow(headers, widths);
            printLine(widths);
        }

        for (int r = 0; r < rowCount; r++) {
            printRow(rows[r], widths);
        }

        printLine(widths);
    }
}