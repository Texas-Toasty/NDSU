
/**
 *
 * @author Reece Parry
 * @version 10/17/2025
 */
public class Client {

    public static void main(String[] args) {

        // Create ASCII Table (9 rows x 6 columns)
        ASCIITable table = new ASCIITable(9, 6);

        // Headers
        String[] headers = {"N", "ArrayStack", "LinkedStack", "ArrayQueue", "LinkedQueue", "ArrayList"};
        table.setHeaders(headers);

        // Test sizes
        int[] testSizes = {10, 100, 1_000, 10_000, 100_000, 1_000_000, 10_000_000, 100_000_000, 1_000_000_000};

        // Perform timing test and fill one row
        for (int n : testSizes) {
            String[] row = new String[6];
            row[0] = String.format("%,d", n);

            row[1] = runArrayStackTest(n);
            row[2] = runLinkedStackTest(n);
            row[3] = runArrayQueueTest(n);
            row[4] = runLinkedQueueTest(n);
            row[5] = runArrayListTest(n);

            table.addRow(row);
        }

        // Print table
        table.printTable();
    }

    // Timing tests
    private static String runArrayStackTest(int n) {
        try {
            ArrayStack stack = new ArrayStack(n);
            long start = System.nanoTime();
            for (int i = 0; i < n; i++) stack.push(i);
            for (int i = 0; i < n; i++) stack.pop();
            return String.format("%,d", (System.nanoTime() - start));
        } catch (OutOfMemoryError e) {
            return "OutOfMemory";
        }
    }

    private static String runLinkedStackTest(int n) {
        try {
            LinkedStack stack = new LinkedStack();
            long start = System.nanoTime();
            for (int i = 0; i < n; i++) stack.push(i);
            for (int i = 0; i < n; i++) stack.pop();
            return String.format("%,d", (System.nanoTime() - start));
        } catch (OutOfMemoryError e) {
            return "OutOfMemory";
        }
    }

    private static String runArrayQueueTest(int n) {
        try {
            ArrayQueue q = new ArrayQueue(n);
            long start = System.nanoTime();
            for (int i = 0; i < n; i++) q.enqueue(i);
            for (int i = 0; i < n; i++) q.dequeue();
            return String.format("%,d", (System.nanoTime() - start));
        } catch (OutOfMemoryError e) {
            return "OutOfMemory";
        }
    }

    private static String runLinkedQueueTest(int n) {
        try {
            LinkedQueue q = new LinkedQueue();
            long start = System.nanoTime();
            for (int i = 0; i < n; i++) q.enqueue(i);
            for (int i = 0; i < n; i++) q.dequeue();
            return String.format("%,d", (System.nanoTime() - start));
        } catch (OutOfMemoryError e) {
            return "OutOfMemory";
        }
    }

    private static String runArrayListTest(int n) {
        try {
            int[] arr = new int[n];
            long start = System.nanoTime();
            for (int i = 0; i < n; i++) arr[i] = i;
            for (int i = 0; i < n; i++) {int temp = arr[i];}
            return String.format("%,d", (System.nanoTime() - start));
        } catch (OutOfMemoryError e) {
            return "OutOfMemory";
        }
    }
}
