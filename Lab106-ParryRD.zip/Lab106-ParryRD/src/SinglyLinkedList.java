
import java.util.Objects;

/**
 *
 * @author Reece Parry
 * @version 10/16/2025
 */
public class SinglyLinkedList<E> {

    //------------ nested Node class ---------
    private static class Node<E> {

        private final E element; // element stored in this node
        private Node<E> next;    // reference to next node

        /**
         * Creates a new node.
         *
         * @param e the element to store
         * @param n the next node
         */
        public Node(E e, Node<E> n) {
            element = e;
            next = n;
        }

        /**
         * @return the element stored in the node
         */
        public E getElement() {
            return element;
        }

        /**
         * @return the next node reference
         */
        public Node<E> getNext() {
            return next;
        }

        /**
         * Sets the next node reference.
         */
        public void setNext(Node<E> n) {
            next = n;
        }
    }

    // Instance variables
    private Node<E> head = null;  // first node
    private Node<E> tail = null;  // last node
    private int size = 0;         // number of nodes

    /**
     * Constructs an initially empty list
     */
    public SinglyLinkedList() {
    }

    /**
     * @return the number of nodes in the list
     */
    public int size() {
        return size;
    }

    /**
     * @return true if the list is empty
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Returns (but does not remove) the first element
     *
     * @return the first element, or null if empty
     */
    public E first() {
        if (isEmpty()) {
            return null;
        }
        return head.getElement();
    }

    /**
     * Returns (but does not remove) the last element
     *
     * @return the last element, or null if empty
     */
    public E last() {
        if (isEmpty()) {
            return null;
        }
        return tail.getElement();
    }

    /**
     * Adds an element to the front of the list
     *
     * @param e the element to add
     */
    public void addFirst(E e) {
        head = new Node<>(e, head);
        if (size == 0) {
            tail = head;
        }
        size++;
    }

    /**
     * Adds an element to the end of the list
     *
     * @param e the element to add
     */
    public void addLast(E e) {
        Node<E> newest = new Node<>(e, null);
        if (isEmpty()) {
            head = newest;
        } else {
            tail.setNext(newest);
        }
        tail = newest;
        size++;
    }

    /**
     * Removes and returns the first element of the list
     *
     * @return the removed element, or null if empty
     */
    public E removeFirst() {
        if (isEmpty()) {
            return null;
        }
        E answer = head.getElement();
        head = head.getNext();
        size--;
        if (size == 0) {
            tail = null;
        }
        return answer;
    }

    /**
     * Clears the list
     */
    public void clear() {
        head = null;
        tail = null;
        size = 0;
    }

    /**
     * Finds the index of the first occurrence of the given element
     *
     * @param e the element to search for
     * @return index of the element, or -1 if not found
     */
    public int indexOf(E e) {
        Node<E> curr = head;
        int idx = 0;
        while (curr != null) {
            if (Objects.equals(curr.getElement(), e)) {
                return idx;
            }
            curr = curr.getNext();
            idx++;
        }
        return -1;
    }

    /**
     * Returns the element at the given index
     *
     * @param index the index
     * @return the element at the index
     * @throws IndexOutOfBoundsException if index is invalid
     */
    public E get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
        }
        Node<E> curr = head;
        for (int i = 0; i < index; i++) {
            curr = curr.getNext();
        }
        return curr.getElement();
    }

    /**
     * Removes and returns the element at the given index
     *
     * @param index the index to remove
     * @return the removed element
     * @throws IndexOutOfBoundsException if index is invalid
     */
    public E removeAt(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
        }
        if (index == 0) {
            return removeFirst();
        }

        Node<E> prev = head;
        for (int i = 0; i < index - 1; i++) {
            prev = prev.getNext();
        }
        Node<E> target = prev.getNext();
        E result = target.getElement();
        prev.setNext(target.getNext());
        size--;
        if (target == tail) {
            tail = prev;
        }
        return result;
    }

    /**
     * Returns a string representation of the list
     *
     * @return string in the form [a, b, c]
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Node<E> curr = head;
        while (curr != null) {
            sb.append(curr.getElement());
            if (curr.getNext() != null) {
                sb.append(", ");
            }
            curr = curr.getNext();
        }
        sb.append("]");
        return sb.toString();
    }
}
