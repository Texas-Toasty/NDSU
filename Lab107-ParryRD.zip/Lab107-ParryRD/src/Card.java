
/**
 *
 * @author Reece Parry
 * @version 10/24/2025
 */
public class Card {

    private final String suit;
    private final String rank;
    private final int value;

    public Card(String suit, String rank, int value) {
        this.suit = suit;
        this.rank = rank;
        this.value = value;
    }

    public String getSuit() {
        return suit;
    }

    public String getRank() {
        return rank;
    }

    public int getValue() {
        return value;
    }

    @Override
    public String toString() {
        String rankStr;

        rankStr = switch (value) {
            case 11 -> "Jack";
            case 12 -> "Queen";
            case 13 -> "King";
            case 14 -> "Ace";
            default -> String.valueOf(value);
        };

        String suitLetter = "";
        switch (suit) {
            case "Hearts" -> suitLetter = "H";
            case "Diamonds" -> suitLetter = "D";
            case "Clubs" -> suitLetter = "C";
            case "Spades" -> suitLetter = "S";
        }

        return rankStr + " " + suitLetter;
    }

}
