
import java.util.Iterator;

/**
 * @author Reece Parry
 * @version 10/24/2025
 */
public class CardHand {

    private final LinkedPositionalList<Card> hand;

    public CardHand() {
        hand = new LinkedPositionalList<>();
    }

    /**
     * Adds a new card to the hand in sorted order (by suit and rank).
     *
     * @param c
     */
    public void addCard(Card c) {
        Position<Card> insertBefore = null;

        for (Position<Card> pos = hand.first(); pos != null; pos = hand.after(pos)) {
            Card current = pos.getElement();

            // First compare suit order
            int suitCompare = compareSuit(c.getSuit(), current.getSuit());
            if (suitCompare < 0) {
                insertBefore = pos;
                break;
            } else if (suitCompare == 0) {
                if (compareRank(c, current) < 0) {
                    insertBefore = pos;
                    break;
                }
            }
        }

        if (insertBefore != null) {
            hand.addBefore(insertBefore, c);
        } else {
            hand.addLast(c); // goes at the end
        }
    }

    /**
     * Displays all cards in order.
     */
    public void displayHand() {
        for (Card c : hand) {
            System.out.println(c);
        }
    }

    /**
     * Returns an iterator over all cards.
     *
     * @return
     */
    public Iterator<Card> iterator() {
        return hand.iterator();
    }

    private int compareSuit(String s1, String s2) {
        return suitValue(s1) - suitValue(s2);
    }

    private int suitValue(String s) {
        return switch (s) {
            case "Spades" ->
                1;
            case "Hearts" ->
                2;
            case "Clubs" ->
                3;
            case "Diamonds" ->
                4;
            default ->
                5;
        };
    }

    /**
     * Rank order: Ace (14), King (13), Queen (12), Jack (11), then 10–2.
     */
    private int compareRank(Card c1, Card c2) {
        return rankValue(c2.getRank()) - rankValue(c1.getRank());
    }

    private int rankValue(String r) {
        return switch (r) {
            case "Ace" ->
                14;
            case "King" ->
                13;
            case "Queen" ->
                12;
            case "Jack" ->
                11;
            default ->
                Integer.parseInt(r);
        };
    }
}
