
/**
 *
 * @author Reece Parry
 * @version 10/24/2025
 */
public class Client {

    public static void main(String[] args) {
        Game game = new Game(4, 13);

        // Deals 13 rounds of cards for a game of spades
        for (int round = 0; round < 13; round++) {
            game.getCard();
            System.out.println("After round " + (round + 1) + ":");
            game.displayHands();
        }
    }
}
