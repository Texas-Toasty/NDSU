
/**
 *
 * @author Reece Parry
 * @version 10/24/2025
 */
import java.util.Random;

public class Deck {

    private final LinkedPositionalList<Card> deck;
    private final Random rand;

    public Deck() {
        deck = new LinkedPositionalList<>();
        rand = new Random();

        String[] suits = {"Spades", "Hearts", "Clubs", "Diamonds"};
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        int[] values = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

        for (String suit : suits) {
            for (int i = 0; i < ranks.length; i++) {
                deck.addLast(new Card(suit, ranks[i], values[i]));
            }
        }
    }

    public Card drawCard() {
        int n = deck.size();
        if (n == 0) {
            return null;
        }

        int randomIndex = rand.nextInt(n);
        Position<Card> pos = deck.first();
        for (int i = 0; i < randomIndex; i++) {
            pos = deck.after(pos);
        }
        Card c = pos.getElement();
        deck.remove(pos);
        return c;
    }
}
