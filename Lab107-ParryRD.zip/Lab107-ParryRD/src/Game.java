
/**
 * @author Reece Parry
 * @version 10/24/2025
 */
public class Game {

    private final int numPlayers;
    private final Deck deck;
    private final ArrayList<CardHand> players;

    public Game(int numPlayers, int maxCards) {
        this.numPlayers = numPlayers;
        deck = new Deck();
        players = new ArrayList<>();

        // Create the players and give each a new hand
        for (int i = 0; i < numPlayers; i++) {
            players.add(new CardHand());
        }
    }

    /**
     * Deals one card from the deck to each player.
     */
    public void getCard() {
        for (int i = 0; i < numPlayers; i++) {
            Card c = deck.drawCard();
            if (c != null) {
                players.get(i).addCard(c);
            }
        }
    }

    /**
     * Displays all player's hands.
     */
    public void displayHands() {
        for (int i = 0; i < players.size(); i++) {
            System.out.println("Player " + (i + 1) + " hand:");
            players.get(i).displayHand();
            System.out.println();
        }
    }
}
