
import java.util.Random;

/**
 *
 * @author Reece Parry
 * @version 11/1/2025
 */
public class Client {

    public static void main(String[] args) {
  
        System.out.println("\n------ Linked Binary Expression Tree Test ------");
        testExpressionTree();
        
        System.out.println("\n");
        
        java.util.Random rand = new Random();

        // -------- Array Stack Testing --------
        System.out.println("--------Printing Array Stack pushing and popping--------");
        ArrayStack<Integer> arrStack = new ArrayStack<>();

        for (int i = 1; i < 11; i++) {
            int v = rand.nextInt(100);
            arrStack.push(v);
            System.out.print("\nPushed: " + v);
        }

        System.out.println("\n");
        while (!arrStack.isEmpty()) {
            int v = arrStack.pop();
            System.out.println("Popped: " + v);
        }

        // -------- Linked Stack Testing --------
        System.out.println("\n--------Printing Linked Stack--------");
        LinkedStack<Integer> linkStack = new LinkedStack<>();

        for (int i = 1; i < 11; i++) {
            int v = rand.nextInt(100);
            linkStack.push(v);
            System.out.println("Pushed: " + v);
        }

        System.out.println("\n");
        while (!linkStack.isEmpty()) {
            int v = linkStack.pop();
            System.out.println("Popped: " + v);
        }

        // -------- Array Queue Testing --------
        System.out.println("\n--------Printing Array Queue--------");
        ArrayQueue<Integer> arrQueue = new ArrayQueue<>();

        for (int i = 1; i < 11; i++) {
            int v = rand.nextInt(100);
            arrQueue.enqueue(v);
            System.out.println("Enqueued: " + v);
        }

        System.out.println("\n");
        while (!arrQueue.isEmpty()) {
            int v = arrQueue.dequeue();
            System.out.println("Dequeued: " + v);
        }

        // -------- Linked Queue Testing --------
        System.out.println("\n--------Printing Linked Queue--------");
        LinkedQueue<Integer> linkQueue = new LinkedQueue<>();

        for (int i = 1; i < 11; i++) {
            int v = rand.nextInt(100);
            linkQueue.enqueue(v);
            System.out.println("Enqueued: " + v);
        }
        System.out.println("\n");
        while (!linkQueue.isEmpty()) {
            int v = linkQueue.dequeue();
            System.out.println("Dequeued: " + v);
        }

        // -------- Positional List Testing --------
        System.out.println("\n--------Printing Positional Linked List--------");
        LinkedPositionalList<Integer> list = new LinkedPositionalList<>();

        for (int i = 1; i < 11; i++) {
            int v = rand.nextInt(100);
            list.addLast(v);
            System.out.println("Added: " + v);
        }

        System.out.println("\n");
        System.out.println("Forward Traversal:");
        for (Integer value : list) {
            System.out.print(value + " ");
        }
        System.out.println();

        System.out.println("\n");

        System.out.println("Backward Traversal:");
        for (Position<Integer> p = list.last(); p != null; p = list.before(p)) {
            System.out.print(p.getElement() + " ");
        }
        System.out.println();
    }

    // -------- Linked Binary Tree Expression --------
    private static void testExpressionTree() {
        // Expression tree from the bottom up
        LinkedBinaryTree<String> leaf5 = makeLeaf("5");
        LinkedBinaryTree<String> leaf2a = makeLeaf("2");
        LinkedBinaryTree<String> leaf1 = makeLeaf("1");
        LinkedBinaryTree<String> leaf2b = makeLeaf("2");
        LinkedBinaryTree<String> leaf2c = makeLeaf("2");
        LinkedBinaryTree<String> leaf9 = makeLeaf("9");
        LinkedBinaryTree<String> leaf7 = makeLeaf("7");
        LinkedBinaryTree<String> leaf2d = makeLeaf("2");
        LinkedBinaryTree<String> leaf8 = makeLeaf("8");

        // A = (2 * 1)
        LinkedBinaryTree<String> A = makeNode("*", leaf2a, leaf1);

        // B = (5 + A)
        LinkedBinaryTree<String> B = makeNode("+", leaf5, A);

        // C = (B - 2)  -> ((5 + 2 * 1) - 2)
        LinkedBinaryTree<String> C = makeNode("-", B, leaf2b);

        // D = (2 + 9)
        LinkedBinaryTree<String> D = makeNode("+", leaf2c, leaf9);

        // E = (7 - 2)
        LinkedBinaryTree<String> E = makeNode("-", leaf7, leaf2d);

        // F = (E - 2)  -> (7 - 2 - 2)
        LinkedBinaryTree<String> F = makeNode("-", E, makeLeaf("2"));

        // G = (D + F) -> ( (2+9) + (7-2-2) )
        LinkedBinaryTree<String> G = makeNode("+", D, F);

        // H = (C / G)
        LinkedBinaryTree<String> H = makeNode("/", C, G);

        // Final = (H * 8)
        LinkedBinaryTree<String> full = makeNode("*", H, leaf8);

        // Print literal string as assignment requests (exact literal)
        System.out.println("\nLiteral expression:");
        System.out.println("( ( ( 5 + 2 * 1 - 2 ) ) / ( ( 2 + 9 ) + ( 7 - 2 - 2 ) ) * 8 )");

        // Print height
        int h = height(full, full.root());
        System.out.println("Height of the expression tree: " + h);

        // Traversals: these return Iterable<Position<E>> in textbook API
        System.out.println("\nPreorder traversal:");
        for (Position<String> pos : full.preorder()) {
            System.out.print(pos.getElement() + " ");
        }
        System.out.println();

        System.out.println("\nInorder traversal:");
        for (Position<String> pos : full.inorder()) {
            System.out.print(pos.getElement() + " ");
        }
        System.out.println();

        System.out.println("\nPostorder traversal:");
        for (Position<String> pos : full.postorder()) {
            System.out.print(pos.getElement() + " ");
        }
        System.out.println();

        System.out.println("\nBreadth-first traversal:");
        for (Position<String> pos : full.breadthfirst()) {
            System.out.print(pos.getElement() + " ");
        }
        System.out.println();

        System.out.println("\nParenthesized representation (Euler's Tour):");
        System.out.println(parenthesize(full, full.root()));
    }

    // Utilities for building small trees and nodes
    private static LinkedBinaryTree<String> makeLeaf(String s) {
        LinkedBinaryTree<String> t = new LinkedBinaryTree<>();
        t.addRoot(s);
        return t;
    }

    /**
     * Make a new tree with root op and attach left & right subtrees (textbook
     * attach). After attach, tLeft and tRight should not be used separately
     * (they become part of the new tree).
     */
    private static LinkedBinaryTree<String> makeNode(String op, LinkedBinaryTree<String> left, LinkedBinaryTree<String> right) {
        LinkedBinaryTree<String> t = new LinkedBinaryTree<>();
        Position<String> r = t.addRoot(op);
        // attach will move left/right under r
        t.attach(r, left, right);
        return t;
    }

    // Compute height recursively (returns number of edges on longest path to a leaf)
    private static <E> int height(Tree<E> tree, Position<E> p) {
        if (tree.isExternal(p)) {
            return 0;
        }
        int h = 0;
        for (Position<E> c : tree.children(p)) {
            h = Math.max(h, 1 + height(tree, c));
        }
        return h;
    }

    // Parenthesize for binary expression trees
    private static String parenthesize(Tree<String> tree, Position<String> p) {
        if (tree.isExternal(p)) {
            return p.getElement();
        } else {
            Position<String> left = ((BinaryTree<String>) tree).left(p);
            Position<String> right = ((BinaryTree<String>) tree).right(p);
            String leftStr = parenthesize(tree, left);
            String rightStr = parenthesize(tree, right);
            return "( " + leftStr + " " + p.getElement() + " " + rightStr + " )";
        }
    }
    
}
