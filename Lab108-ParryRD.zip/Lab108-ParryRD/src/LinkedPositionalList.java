/**
 * Implementation of a positional list stored as a doubly linked list.
 * 
 * @author Reece Parry
 * @version 10/21/2025
 * @param <E> the type of elements stored in the list
 */
import java.util.Iterator;

public class LinkedPositionalList<E> implements PositionalList<E>, Iterable<E> {

    // ---------- Nested Node class ----------
    private static class Node<E> implements Position<E> {
        private E element;        // element stored at this node
        private Node<E> prev;     // previous node in the list
        private Node<E> next;     // next node in the list

        public Node(E e, Node<E> p, Node<E> n) {
            element = e;
            prev = p;
            next = n;
        }

        @Override
        public E getElement() throws IllegalStateException {
            if (next == null) // convention for defunct node
                throw new IllegalStateException("Position no longer valid");
            return element;
        }

        public Node<E> getPrev() { return prev; }
        public Node<E> getNext() { return next; }
        public void setElement(E e) { element = e; }
        public void setPrev(Node<E> p) { prev = p; }
        public void setNext(Node<E> n) { next = n; }
    }
    // ---------- End of nested Node class ----------


    // ---------- Instance variables ----------
    private final Node<E> header;   // header sentinel
    private final Node<E> trailer;  // trailer sentinel
    private int size = 0;     // number of elements in the list


    // ---------- Constructor ----------
    /** Constructs a new empty list. */
    public LinkedPositionalList() {
        header = new Node<>(null, null, null);      // create header
        trailer = new Node<>(null, header, null);   // trailer follows header
        header.setNext(trailer);                    // link header and trailer
    }


    // ---------- Private utilities ----------
    /** Validates the position and returns it as a node. */
    private Node<E> validate(Position<E> p) throws IllegalArgumentException {
        if (!(p instanceof Node))
            throw new IllegalArgumentException("Invalid p");
        Node<E> node = (Node<E>) p;
        if (node.getNext() == null) // defunct node
            throw new IllegalArgumentException("p is no longer in the list");
        return node;
    }

    /** Returns the given node as a Position (or null, if it is a sentinel). */
    private Position<E> position(Node<E> node) {
        if (node == header || node == trailer)
            return null; // don’t expose sentinels
        return node;
    }


    // ---------- Accessor methods ----------
    @Override
    public int size() { return size; }
    @Override
    public boolean isEmpty() { return size == 0; }

    @Override
    public Position<E> first() { return position(header.getNext()); }
    @Override
    public Position<E> last() { return position(trailer.getPrev()); }

    @Override
    public Position<E> before(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return position(node.getPrev());
    }

    @Override
    public Position<E> after(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return position(node.getNext());
    }


    // ---------- Private utility for insertion ----------
    /** Adds element e to the linked list between the given nodes. */
    private Position<E> addBetween(E e, Node<E> pred, Node<E> succ) {
        Node<E> newest = new Node<>(e, pred, succ);
        pred.setNext(newest);
        succ.setPrev(newest);
        size++;
        return newest;
    }


    // ---------- Update methods ----------
    @Override
    public Position<E> addFirst(E e) {
        return addBetween(e, header, header.getNext());
    }

    @Override
    public Position<E> addLast(E e) {
        return addBetween(e, trailer.getPrev(), trailer);
    }

    @Override
    public Position<E> addBefore(Position<E> p, E e) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return addBetween(e, node.getPrev(), node);
    }

    @Override
    public Position<E> addAfter(Position<E> p, E e) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return addBetween(e, node, node.getNext());
    }

    @Override
    public E set(Position<E> p, E e) throws IllegalArgumentException {
        Node<E> node = validate(p);
        E answer = node.getElement();
        node.setElement(e);
        return answer;
    }

    @Override
    public E remove(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        Node<E> predecessor = node.getPrev();
        Node<E> successor = node.getNext();
        predecessor.setNext(successor);
        successor.setPrev(predecessor);
        size--;

        E answer = node.getElement();
        node.setElement(null);
        node.setPrev(null);
        node.setNext(null);
        return answer;
    }


    // ---------- Iterator Support ----------
    private class ElementIterator implements Iterator<E> {
        private Position<E> cursor = first(); // position of next element

        @Override
        public boolean hasNext() {
            return (cursor != null);
        }

        @Override
        public E next() {
            E answer = cursor.getElement();
            cursor = after(cursor);
            return answer;
        }
    }

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator();
    }
}
