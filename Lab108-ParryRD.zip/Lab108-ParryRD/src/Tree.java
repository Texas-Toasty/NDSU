
import java.util.Iterator;

/**
* Data Structures & Algorithms 6th Edition
* Goodrick, Tamassia, Goldwasser
* Code Fragments 6.1
*
* An implementation of a simple Tree interface.
* Taken directly from the textbook.
*
* @author Michael T. Goodrich
* @author Roberto Tamassia
* @author Michael H. Goldwasser
*
* @author Reece Parry, transcribed by
* @version 11/1/2025
 * @param <E>
*/

public interface Tree<E> extends Iterable<E> {

    Position<E> root();

    Position<E> parent(Position<E> p) throws IllegalArgumentException;

    Iterable<Position<E>> children(Position<E> p) throws IllegalArgumentException;

    int numChildren(Position<E> p) throws IllegalArgumentException;

    boolean isInternal(Position<E> p) throws IllegalArgumentException;

    boolean isExternal(Position<E> p) throws IllegalArgumentException;

    boolean isRoot(Position<E> p) throws IllegalArgumentException;

    int size();

    boolean isEmpty();

    @Override
    Iterator<E> iterator();

    Iterable<Position<E>> positions();

}
