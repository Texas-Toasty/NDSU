
/**
 * @author Reece
 * @version 11/16/2025
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the absolute path and filename: ");
        String filePath = input.nextLine();

        File file = new File(filePath);

        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String expression = fileScanner.nextLine().trim();

                if (expression.isEmpty()) {
                    continue;
                }

                System.out.println("\nExpression: " + expression);

                // Validate

                if (!ExpressionValidator.isValid(expression)) {
                    System.out.println("Invalid expression.");
                    continue;
                }

                // Tokenize

                java.util.List<String> tokens = Tokenizer.tokenize(expression);

                // Infix to Postfix

                LinkedQueue<String> postfix = ShuntingYard.infixToPostfix(tokens);

                System.out.print("Postfix: ");
                printLinkedQueue(postfix);

                LinkedQueue<String> evalQueue = copyLinkedQueue(postfix);      // copy for evaluator (consumed)
                java.util.List<String> postfixList = linkedQueueToList(postfix); // list for builder

                // Evaluate
                
                double result = PostfixEvaluator.evaluate(evalQueue);
                System.out.println("Result: " + result);

                // Build expression tree

                ExpressionTreeBuilder builder = new ExpressionTreeBuilder();
                ExpressionTree tree = builder.buildTree(postfixList);

                // Print traversals & Euler tour

                ExpressionTreePrinter printer = new ExpressionTreePrinter();
                printer.print(tree);

                System.out.println(); // blank line between expressions
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
        }

        input.close();
    }

    // -----------------------------
    // Helper utilities for your custom LinkedQueue
    // -----------------------------
    // NOTE: these helpers do not assume LinkedQueue implements java.util.Collection.
    // They use the basic operations: size(), dequeue(), enqueue(), isEmpty().
    private static void printLinkedQueue(LinkedQueue<String> q) {
        if (q == null) {
            return;
        }
        int n = q.size();
        for (int i = 0; i < n; i++) {
            String tok = q.dequeue();
            System.out.print(tok + " ");
            q.enqueue(tok);   // rotate back
        }
        System.out.println();
    }

    private static LinkedQueue<String> copyLinkedQueue(LinkedQueue<String> src) {
        LinkedQueue<String> copy = new LinkedQueue<>();
        if (src == null) {
            return copy;
        }
        int n = src.size();
        for (int i = 0; i < n; i++) {
            String tok = src.dequeue();
            copy.enqueue(tok); // add to copy
            src.enqueue(tok);  // rotate back to original
        }
        return copy;
    }

    private static List<String> linkedQueueToList(LinkedQueue<String> src) {
        List<String> list = new ArrayList<>();
        if (src == null) {
            return list;
        }
        int n = src.size();
        for (int i = 0; i < n; i++) {
            String tok = src.dequeue();
            list.add(tok);
            src.enqueue(tok);  // rotate back
        }
        return list;
    }
}
