
/**
 * @author Reece Parry
 * @version 11/12/2025
 */
public class ExpressionTree {

    private final Node root;

    // Constructor used by the ExpressionTreeBuilder
    public ExpressionTree(Node root) {
        this.root = root;
    }

    // ===============================
    // NESTED STATIC NODE CLASS
    // ===============================
    public static class Node {

        private final String token;
        private Node left;
        private Node right;

        public Node(String token) {
            this.token = token;
        }

        public String getToken() { return token; }
        public Node getLeft() { return left; }
        public Node getRight() { return right; }

        public void setLeft(Node left) { this.left = left; }
        public void setRight(Node right) { this.right = right; }

        @Override
        public String toString() {
            return token;
        }
    }


    // ======================================
    // Evaluation
    // ======================================
    public double evaluate() {
        return evaluate(root);
    }

    private double evaluate(Node node) {
        if (node == null) return 0.0;

        // Leaf = number
        if (isNumber(node.token))
            return Double.parseDouble(node.token);

        // Otherwise operator
        double leftVal = evaluate(node.left);
        double rightVal = evaluate(node.right);
        String op = node.token;

        return switch (op) {
            case "+" -> leftVal + rightVal;
            case "-" -> leftVal - rightVal;
            case "*" -> leftVal * rightVal;
            case "/" -> leftVal / rightVal;
            default -> throw new IllegalArgumentException("Unknown operator: " + op);
        };
    }


    // ======================================
    // Pre-order traversal
    // ======================================
    public String preorder() {
        StringBuilder sb = new StringBuilder();
        preorder(root, sb);
        return sb.toString().trim();
    }

    private void preorder(Node node, StringBuilder sb) {
        if (node == null) return;

        sb.append(node.token).append(" ");
        preorder(node.left, sb);
        preorder(node.right, sb);
    }


    // ======================================
    // In-order traversal
    // ======================================
    public String inorder() {
        StringBuilder sb = new StringBuilder();
        inorder(root, sb);
        return sb.toString().trim();
    }

    private void inorder(Node node, StringBuilder sb) {
        if (node == null) return;

        inorder(node.left, sb);
        sb.append(node.token).append(" ");
        inorder(node.right, sb);
    }


    // ======================================
    // Post-order traversal
    // ======================================
    public String postorder() {
        StringBuilder sb = new StringBuilder();
        postorder(root, sb);
        return sb.toString().trim();
    }

    private void postorder(Node node, StringBuilder sb) {
        if (node == null) return;

        postorder(node.left, sb);
        postorder(node.right, sb);
        sb.append(node.token).append(" ");
    }


    // ======================================
    // Euler Tour (fully parenthesized)
    // ======================================
    public String eulerTour() {
        return euler(root);
    }

    private String euler(Node node) {
        if (node == null) return "";

        // Leaf
        if (isNumber(node.token))
            return node.token;

        // Internal node
        return "(" +
                euler(node.left) +
                " " + node.token + " " +
                euler(node.right) +
                ")";
    }


    // ======================================
    // Helpers
    // ======================================
    private boolean isOperator(String s) {
        return "+-*/".contains(s);
    }

    private boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
