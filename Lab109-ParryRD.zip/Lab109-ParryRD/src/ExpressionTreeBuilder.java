import java.util.List;
import java.util.Stack;

public class ExpressionTreeBuilder {

    public ExpressionTreeBuilder() {}

    public ExpressionTree buildTree(List<String> postfixTokens) {

        Stack<ExpressionTree.Node> stack = new Stack<>();

        for (String token : postfixTokens) {

            if (isNumber(token)) {
                stack.push(new ExpressionTree.Node(token));
            }
            else if (isOperator(token)) {

                ExpressionTree.Node right = stack.pop();
                ExpressionTree.Node left = stack.pop();

                ExpressionTree.Node opNode = new ExpressionTree.Node(token);
                opNode.setLeft(left);
                opNode.setRight(right);

                stack.push(opNode);
            }
        }

        ExpressionTree.Node root = stack.pop();
        return new ExpressionTree(root);
    }

    private boolean isOperator(String s) {
        return "+-*/".contains(s);
    }

    private boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
