
/**
 * @author Reece Parry
 * @version 11/12/2025
 */
public class ExpressionTreePrinter {

    /**
     * Print all required traversals of the given expression tree.
     * @param tree
     */
    public void print(ExpressionTree tree) {

        System.out.println("Pre-order traversal:");
        System.out.println(tree.preorder());
        System.out.println();

        System.out.println("In-order traversal:");
        System.out.println(tree.inorder());
        System.out.println();

        System.out.println("Post-order traversal:");
        System.out.println(tree.postorder());
        System.out.println();

        System.out.println("Euler Tour (fully parenthesized expression):");
        System.out.println(tree.eulerTour());
        System.out.println();
    }
}
