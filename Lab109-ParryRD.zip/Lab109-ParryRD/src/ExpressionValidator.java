
/**
 * @author Reece Parry
 * @version 11/12/2025
 */
public class ExpressionValidator {

    // Returns true if the expression is valid
    public static boolean isValid(String expr) {
        LinkedStack<Character> stack = new LinkedStack<>();

        for (int i = 0; i < expr.length(); i++) {
            char ch = expr.charAt(i);

            if (isOpeningSymbol(ch)) {
                stack.push(ch);
            } else if (isClosingSymbol(ch)) {
                if (stack.isEmpty()) return false;
                char open = stack.pop();
                if (!matches(open, ch)) return false;
            }
        }

        // if stack not empty, unbalanced
        return stack.isEmpty();
    }

    private static boolean isOpeningSymbol(char c) {
        return c == '(' || c == '{' || c == '[';
    }

    private static boolean isClosingSymbol(char c) {
        return c == ')' || c == '}' || c == ']';
    }

    private static boolean matches(char open, char close) {
        return (open == '(' && close == ')') ||
               (open == '{' && close == '}') ||
               (open == '[' && close == ']');
    }
}
