
/**
 * Minimal Position interface.
 *
 * @author Reece Parry
 * @version 10/21/2025
 * @param <E>
 */
public interface Position<E> {

    E getElement();
}
