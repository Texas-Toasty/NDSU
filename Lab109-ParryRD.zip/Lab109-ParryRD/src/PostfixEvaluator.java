
/**
 * @author Reece Parry
 * @version 11/16/2025
 */
public class PostfixEvaluator {

    public static double evaluate(LinkedQueue<String> postfix) {
        LinkedStack<Double> stack = new LinkedStack<>();

        int size = postfix.size();

        for (int i = 0; i < size; i++) {
            String token = postfix.dequeue();
            postfix.enqueue(token);  // Put back so the queue stays intact

            // If token is a number, push
            if (isNumber(token)) {
                stack.push(Double.parseDouble(token));
            } // If operator, pop two, compute, and push result
            else if (isOperator(token)) {
                double right = stack.pop();
                double left = stack.pop();
                stack.push(applyOperator(left, right, token));
            }
        }

        // Final answer is the only value on the stack
        return stack.pop();
    }

    private static boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isOperator(String s) {
        return s.equals("+") || s.equals("-")
                || s.equals("*") || s.equals("/");
    }

    private static double applyOperator(double a, double b, String op) {
        switch (op) {
            case "+" -> {
                return a + b;
            }
            case "-" -> {
                return a - b;
            }
            case "*" -> {
                return a * b;
            }
            case "/" -> {
                return a / b;
            }
            default -> throw new IllegalArgumentException("Unknown operator: " + op);
        }
    }
}
