
/**
 * @author Reece Parry
 * @version 11/16/2025
 */
import java.util.List;

public class ShuntingYard {

    // Converts an infix expression to postfix
    public static LinkedQueue<String> infixToPostfix(List<String> tokens) {
        LinkedQueue<String> output = new LinkedQueue<>();
        LinkedStack<String> opStack = new LinkedStack<>();

        for (String token : tokens) {

            
            if (isNumber(token)) {
                output.enqueue(token);
            } 
            else if (isOperator(token)) {

                while (!opStack.isEmpty()
                        && isOperator(opStack.top())
                        && (higherPrecedence(opStack.top(), token)
                        || (samePrecedence(opStack.top(), token) && isLeftAssociative(token)))) {

                    output.enqueue(opStack.pop());
                }
                opStack.push(token);
            } 
            else if (isOpening(token)) {
                opStack.push(token);
            } 
            else if (isClosing(token)) {
                while (!opStack.isEmpty() && !isOpening(opStack.top())) {
                    output.enqueue(opStack.pop());
                }

                if (!opStack.isEmpty()) {
                    opStack.pop();
                }
            }
        }

        while (!opStack.isEmpty()) {
            output.enqueue(opStack.pop());
        }

        return output;
    }

    // --------------------
    // Helper methods:
    // --------------------
    private static boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isOperator(String s) {
        return s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/");
    }

    private static boolean isOpening(String s) {
        return s.equals("(") || s.equals("[") || s.equals("{");
    }

    private static boolean isClosing(String s) {
        return s.equals(")") || s.equals("]") || s.equals("}");
    }

    private static int precedence(String op) {
        if (op.equals("*") || op.equals("/")) {
            return 2;
        }
        if (op.equals("+") || op.equals("-")) {
            return 1;
        }
        return 0;
    }

    private static boolean higherPrecedence(String op1, String op2) {
        return precedence(op1) > precedence(op2);
    }

    private static boolean samePrecedence(String op1, String op2) {
        return precedence(op1) == precedence(op2);
    }

    private static boolean isLeftAssociative(String op) {
        return true;
    }
}
