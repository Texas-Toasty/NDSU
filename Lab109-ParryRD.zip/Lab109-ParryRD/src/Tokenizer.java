
/**
 * @author Reece Parry
 * @version 11/16/2025
 */
import java.util.ArrayList;
import java.util.List;

public class Tokenizer {

    public static List<String> tokenize(String expr) {
        List<String> tokens = new ArrayList<>();
        StringBuilder number = new StringBuilder();

        for (int i = 0; i < expr.length(); i++) {
            char c = expr.charAt(i);

            // Skip spaces
            if (Character.isWhitespace(c)) {
                if (number.length() > 0) {
                    tokens.add(number.toString());
                    number.setLength(0);
                }
                continue;
            }

            // If digit or decimal, build number
            if (Character.isDigit(c) || c == '.') {
                number.append(c);
                continue;
            }

            // Handle unary minus (like -45 or -12)
            if (c == '-' && (tokens.isEmpty()
                    || isOpening(tokens.get(tokens.size() - 1))
                    || isOperator(tokens.get(tokens.size() - 1)))) {

                number.append(c);
                continue;
            }

            if (number.length() > 0) {
                tokens.add(number.toString());
                number.setLength(0);
            }

            // Parentheses/brackets/braces
            if ("()[]{}".indexOf(c) >= 0) {
                tokens.add(String.valueOf(c));
                continue;
            }

            // Operators
            if ("+-*/".indexOf(c) >= 0) {
                tokens.add(String.valueOf(c));
                continue;
            }

        }

        if (number.length() > 0) {
            tokens.add(number.toString());
        }

        return tokens;
    }

    private static boolean isOpening(String s) {
        return s.equals("(") || s.equals("[") || s.equals("{");
    }

    private static boolean isOperator(String s) {
        return s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/");
    }
}
