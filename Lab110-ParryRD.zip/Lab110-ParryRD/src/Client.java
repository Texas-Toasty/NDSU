
import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Reece Parry
 * @version 11/21/2025
 */
public class Client {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter starting directory: ");
        String path = scanner.nextLine();

        File dir = new File(path);

        if (!dir.exists() || !dir.isDirectory()) {
            System.out.println("Invalid directory.");
            scanner.close();
            return;
        }

        File[] files = dir.listFiles();

        if (files == null || files.length == 0) {
            System.out.println("No files found in the directory.");
            scanner.close();
            return;
        }

        ASCIITable table = new ASCIITable(files.length, 4);

        table.setHeaders(new String[]{"Filename", "Character", "Word", "Line"});

        for (File f : files) {

            if (f.isDirectory()) {
                continue;
            }

            FileProcessor fp = new FileProcessor(f);

            Character[] chars = fp.getCharacterArray();
            String[] words = fp.getWordArray();
            String[] lines = fp.getLineArray();

            boolean charPalindrome = (chars.length > 1) && isPalindrome(chars);
            boolean wordPalindrome = (words.length > 1) && isPalindrome(words);
            boolean linePalindrome = (lines.length > 1) && isPalindrome(lines);

            String charResult = charPalindrome ? "Y" : "N";
            String wordResult = wordPalindrome ? "Y" : "N";
            String lineResult = linePalindrome ? "Y" : "N";

            table.addRow(new String[]{
                f.getName(),
                charResult,
                wordResult,
                lineResult
            });

        }

        table.printTable();
        scanner.close();

    }

    /**
     * IsPalindrome method checks each array created from .txt files to
     * determine if the words, lines, or characters are palindromes.
     * @param <T>
     * @param arr
     * @return 
     */
    public static <T> boolean isPalindrome(T[] arr) {
        int left = 0;
        int right = arr.length - 1;

        while (left < right) {
            if (!arr[left].equals(arr[right])) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }

    /**
     * IsValidPalindrome method checks each array created from .txt files to
     * determine if the words, lines, or characters are valid palindromes.
     * (Safeguard)
     * @param <T>
     * @param arr
     * @return 
     */
    public static <T> boolean isValidPalindrome(T[] arr) {
        if (arr.length <= 1) {
            return false;
        }
        return isPalindrome(arr);
    }

}
