
import java.io.*;
import java.util.*;

/**
 *
 * @author Reece Parry
 * @version 11/21/2025
 */
public class FileProcessor {

    private final File file;
    private final ArrayList<Character> charList = new ArrayList<>();
    private final ArrayList<String> wordList = new ArrayList<>();
    private final ArrayList<String> lineList = new ArrayList<>();

    /**
     * Constructor.
     * @param file
     */
    public FileProcessor(File file) {
        this.file = file;
        process();
    }

    private void process() {
        try (Scanner scan = new Scanner(file)) {

            while (scan.hasNextLine()) {
                String line = scan.nextLine();

                // Store raw lines for line palindrome.
                String cleanedLine = line
                        .replaceAll("[^a-zA-Z0-9 ]", "")
                        .trim()
                        .toLowerCase();

                if (!cleanedLine.isEmpty()) {
                    lineList.add(cleanedLine);
                }

                // Build words.
                String[] words = cleanedLine.split("\\s+");
                for (String w : words) {
                    if (!w.isEmpty()) {
                        wordList.add(w);

                        for (char c : w.toCharArray()) {
                            charList.add(c);
                        }
                    }
                }
            }

        } catch (Exception e) {
        }
    }

    public Character[] getCharacterArray() {
        return charList.toArray(Character[]::new);
    }

    public String[] getWordArray() {
        return wordList.toArray(String[]::new);
    }

    public String[] getLineArray() {
        return lineList.toArray(String[]::new);
    }
}
