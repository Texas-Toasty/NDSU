
import java.util.Scanner;
import java.util.concurrent.*;

/**
 *
 * @author Reece Parry
 * @version 12/05/2025
 */
public class Client {

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    public static void runWithTimeout(String label, Runnable task, int timeoutSeconds) {
        System.out.println("\nRunning: " + label + "...");

        Future<?> future = executor.submit(task); // Holds task for future run
        long start = System.currentTimeMillis();

        try {
            future.get(timeoutSeconds, TimeUnit.SECONDS);
            long end = System.currentTimeMillis();
            System.out.println(label + " completed in " + (end - start) + " ms");

        } catch (TimeoutException e) {
            future.cancel(true);  // kill the sort
            System.out.println(label + " TIMED OUT after " + timeoutSeconds + " seconds.");

        } catch (InterruptedException | ExecutionException e) {
            System.out.println(label + " FAILED: " + e.getMessage());
        }
    }

    private static void withCopy(Employee[] employees, Runnable sortAction) {
        Employee[] copy = Employee.copyArray(employees);
        sortAction.run();
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("How long do you want the program to run before timing out? (in seconds): ");
        int timeOut = input.nextInt();

        int[] testSizes = {1000, 10000, 100000, 1000000};

        for (int n : testSizes) {

            System.out.println("\n-----------------");
            System.out.println("Testing with n = " + n);
            System.out.println("-----------------");

            // Generate employees
            Employee[] employees = new Employee[n];
            for (int i = 0; i < n; i++) {
                employees[i] = Employee.randomEmployee();
            }

            // ----- Merge Sort -----
            runWithTimeout("Merge Sort (by Name)", ()
                    -> withCopy(employees, ()
                            -> Sort.mergeSort(Employee.copyArray(employees), Employee.byName)
                    ),
                     timeOut);

            // ----- Quick Sort -----
            runWithTimeout("Quick Sort (by Dept)", () -> {
                Employee[] copy = Employee.copyArray(employees);

                // Convert to queue
                LinkedQueue<Employee> q = new LinkedQueue<>();
                for (Employee e : copy) {
                    q.enqueue(e);
                }

                Sort.quickSort(q, Employee.byDept);
            }, timeOut);

            // Simply bubble sort
            runWithTimeout("Simple Bubble Sort (by ID)", ()
                    -> Sort.simpleBubbleSort(Employee.copyArray(employees), Employee.byId),
                     timeOut);

            // Enhanced bubble sort
            runWithTimeout("Enhanced Bubble Sort (by Hire Date)", ()
                    -> Sort.enhancedBubbleSort(Employee.copyArray(employees), Employee.byHired),
                     timeOut);

            // Insertion sort
            runWithTimeout("Insertion Sort (by Name)", ()
                    -> Sort.insertionSort(Employee.copyArray(employees), Employee.byName),
                     timeOut);

            // Selection sort
            runWithTimeout("Selection Sort (by ID)", ()
                    -> Sort.selectionSort(Employee.copyArray(employees), Employee.byId),
                     timeOut);

            // Radix sort
            runWithTimeout("Radix Sort (Dept -> Hired -> Name)", ()
                    -> Sort.radixSort(Employee.copyArray(employees), Employee.byDept, Employee.byHired, Employee.byName),
                     timeOut);
        }

        executor.shutdownNow();
        System.out.println("\nAll tests finished.");
    }
}
