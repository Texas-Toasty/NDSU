
/**
 *
 * @author Reece Parry
 * @version 12/05/2025
 * @param <K>
 */
public interface Comparator<K> {
    int compare(K a, K b);
}
