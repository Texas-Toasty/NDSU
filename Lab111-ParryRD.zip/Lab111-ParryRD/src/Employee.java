
import java.util.Random;

public class Employee {

    private int id;         // 0–99,999,999
    private String name;    // 5–10 lowercase chars
    private int dept;       // 1–5
    private int hired;      // 2008–2018

    private static Random rand = new Random();

    // Constructor
    public Employee(int id, String name, int dept, int hired) {
        this.id = id;
        this.name = name;
        this.dept = dept;
        this.hired = hired;
    }

    //  Create a random employee
    public static Employee randomEmployee() {
        int id = rand.nextInt(100000000);      // 0–99,999,999
        String name = randomName(5, 10);       // 5–10 chars
        int dept = rand.nextInt(5) + 1;        // 1–5
        int hired = rand.nextInt(11) + 2008;   // 2008–2018
        return new Employee(id, name, dept, hired);
    }

    //  Random name generator
    private static String randomName(int min, int max) {
        int length = rand.nextInt(max - min + 1) + min;
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < length; i++) {
            char c = (char) ('a' + rand.nextInt(26));
            sb.append(c);
        }

        return sb.toString();
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getDept() {
        return dept;
    }

    public int getHired() {
        return hired;
    }

    @Override
    public String toString() {
        return String.format(
                "ID: %08d | Name: %-10s | Dept: %d | Hired: %d",
                id, name, dept, hired
        );
    }

    public static Employee[] copyArray(Employee[] arr) {
        Employee[] copy = new Employee[arr.length];
        System.arraycopy(arr, 0, copy, 0, arr.length);
        return copy;
    }

    // Comparator for ID
    public static Comparator<Employee> byId = (Employee a, Employee b) -> Integer.compare(a.id, b.id);

    // Comparator for Name
    public static Comparator<Employee> byName = (Employee a, Employee b) -> a.name.compareTo(b.name);

    // Comparator for Dept
    public static Comparator<Employee> byDept = (Employee a, Employee b) -> Integer.compare(a.dept, b.dept);

    // Comparator for Hired-Year
    public static Comparator<Employee> byHired = (Employee a, Employee b) -> Integer.compare(a.hired, b.hired);
}
