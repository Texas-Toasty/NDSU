
import java.util.Arrays; // Only used in mergeSort

/**
 *
 * @author Reece Parry
 * @version 12/05/2025
 */
public class Sort {

    public static <K> void simpleBubbleSort(K[] data, Comparator<K> comp) {

        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data.length - 1; j++) {

                if (comp.compare(data[j], data[j + 1]) > 0) {
                    K temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }

            }
        }
    }

    public static <K> void enhancedBubbleSort(K[] array, Comparator<K> comp) {

        boolean swapped = true;
        int n = array.length;

        // Continue until no swaps occur
        while (swapped) {
            swapped = false;

            // Only sort the unsorted portion
            for (int i = 0; i < n - 1; i++) {
                // stable: only swap if strictly greater
                if (comp.compare(array[i], array[i + 1]) > 0) {
                    K temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;

                    swapped = true;
                }
            }

            // After each full pass, the last element is in correct position
            n--;
        }
    }

    public static <K> void insertionSort(K[] array, Comparator<K> comp) {
        for (int i = 1; i < array.length; i++) {

            K temp = array[i];
            int j = i;

            // use the comparator instead of >
            while (j > 0 && comp.compare(array[j - 1], temp) > 0) {
                array[j] = array[j - 1];
                j--;
            }

            array[j] = temp;
        }
    }

    public static <K> int indexOfLargestElement(K[] array, int size, Comparator<K> comp) {
        int index = 0;

        for (int i = 1; i < size; i++) {
            if (comp.compare(array[i], array[index]) > 0) {
                index = i;
            }
        }

        return index;
    }

    public static <K> void selectionSort(K[] array, Comparator<K> comp) {

        for (int i = 0; i < array.length; i++) {
            int maxIndex = indexOfLargestElement(array, array.length - i, comp);

            K temp = array[maxIndex];
            array[maxIndex] = array[array.length - i - 1];
            array[array.length - i - 1] = temp;
        }
    }

    /**
     * Merge contents of arrays S1 and S2 into properly sized array S.
     *
     * @param <K>
     * @param S1
     * @param S2
     * @param S
     * @param comp
     */
    public static <K> void merge(K[] S1, K[] S2, K[] S, Comparator<K> comp) {
        int i = 0, j = 0;
        while (i + j < S.length) {
            if (j == S2.length || (i < S1.length && comp.compare(S1[i], S2[j]) < 0)) {
                S[i + j] = S1[i++];               // copy ith element of S1 and increment i
            } else {
                S[i + j] = S2[j++];                // copy jth element of S2 and increment j
            }
        }
    }

    public static <K> void mergeSort(K[] S, Comparator<K> comp) {
        int n = S.length;
        if (n < 2) {
            return;                              // array is trivially sorted
        }
        int mid = n / 2;
        K[] S1 = Arrays.copyOfRange(S, 0, mid);         // copy of first half
        K[] S2 = Arrays.copyOfRange(S, mid, n);         // copy of second half
        // conquer (with recursion)
        mergeSort(S1, comp);                            // sort copy of first half
        mergeSort(S2, comp);                            // sort copy of second half
        // merge results
        merge(S1, S2, S, comp);              // merge sorted halves back into original
    }

    /**
     * Quick-sort contents of a queue.
     *
     * @param <K>
     * @param S
     * @param comp
     */
    public static <K> void quickSort(Queue<K> S, Comparator<K> comp) {
        int n = S.size();
        if (n < 2) {
            return;                      // queue is trivially sorted
        }
        K pivot = S.first();                    // using first as arbitrary pivot
        Queue<K> L = new LinkedQueue<>();
        Queue<K> E = new LinkedQueue<>();
        Queue<K> G = new LinkedQueue<>();
        while (!S.isEmpty()) {                   // divide original into L, E, and G
            K element = S.dequeue();
            int c = comp.compare(element, pivot);
            if (c < 0) // element is less than pivot
            {
                L.enqueue(element);
            } else if (c == 0) // element is equal to pivot
            {
                E.enqueue(element);
            } else // element is greater than pivot
            {
                G.enqueue(element);
            }
        }
        // conquer
        quickSort(L, comp);                     // sort elements less than pivot
        quickSort(G, comp);                     // sort elements greater than pivot
        // concatenate results
        while (!L.isEmpty()) {
            S.enqueue(L.dequeue());
        }
        while (!E.isEmpty()) {
            S.enqueue(E.dequeue());
        }
        while (!G.isEmpty()) {
            S.enqueue(G.dequeue());
        }
    }

    public static <K> void radixSort(K[] data, Comparator<K> comp1, Comparator<K> comp2, Comparator<K> comp3) {
        
        enhancedBubbleSort(data, comp3);
        enhancedBubbleSort(data, comp2);
        enhancedBubbleSort(data, comp1);
        
    }

}
